package com.example.springdemojdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemoJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
