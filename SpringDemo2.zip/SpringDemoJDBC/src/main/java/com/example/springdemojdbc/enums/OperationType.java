package com.example.springdemojdbc.enums;

public enum OperationType {
    ADD, EXIT
}
