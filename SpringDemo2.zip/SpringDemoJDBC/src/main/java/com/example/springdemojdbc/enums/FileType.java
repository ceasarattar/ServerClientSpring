package com.example.springdemojdbc.enums;

public enum FileType {
    JDBC;
}
